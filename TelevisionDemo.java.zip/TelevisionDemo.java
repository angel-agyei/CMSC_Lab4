import java.util.Scanner;
public class TelevisionDemo {

	private static Scanner keyboard;

	public static void main(String[] args) {
		/** This program that is supposed to be another Television instance
		 *
		 * 
		 * */


		keyboard = new Scanner(System.in);
		//variables
		int station; //the user's channel choice
		//introduce a television object
		Television bigScreen = new Television("Toshiba", 55);
		//Power on - (+)
		bigScreen.power();
		//display the television
		System.out.println("A " + bigScreen.getScreenSize() + " inch "+
		bigScreen.getManufacturer() +
		" has been turned on.");

		//Tells the user to insert the channel they want (number)
		System.out.print("What channel do you want? ");
		station = keyboard.nextInt();
		
		//change the channel on the television
		bigScreen.setChannel(station);
		//increase the volume of the television
		bigScreen.increaseVolume();
		
		//This should tell what the current channel the tv is on and the current volume setting.
		System.out.println("Channel: " +
		bigScreen.getChannel() +
		" Volume: " + bigScreen.getTvVolume());
		//When the volume is too loud
		System.out.println(
		"The Volume is Too loud!! I am lowering the volume! :( ");

		//The program decreases the Volume of the current Tv setting
		bigScreen.decreaseVolume();
		bigScreen.decreaseVolume();
		bigScreen.decreaseVolume();
		bigScreen.decreaseVolume();
		bigScreen.decreaseVolume();
		bigScreen.decreaseVolume();

		//This should tell what the current channel the tv is on and the current volume setting.
		System.out.println("Channel: " +
		bigScreen.getChannel() +
		" Volume: " + bigScreen.getTvVolume());

		System.out.println(); //for a blank line

		//Another television Instance- Specifically for Part 5 of the Lab
		Television portable=new Television("Sharp", 19);
		portable.power();

		//This should say the current state of the television
		System.out.println("A " + portable.getScreenSize() + " inch "+
		portable.getManufacturer() +
		" has been turned on.");

		//This should be an output that asks the inputer to input the channel they want
		System.out.print("What channel would you like to watch? ");

		station = keyboard.nextInt();
		//This should change the tv's channel (x)
		portable.setChannel(station);
		//This should decrease the current volume of the TV (-)
		portable.decreaseVolume();
		portable.decreaseVolume();

		//This should tell what the current channel the tv is on and the current volume setting.
		System.out.println("Channel: " +
		portable.getChannel() +
		" Volume: " + portable.getTvVolume());

	} // end of class

} //end of main
