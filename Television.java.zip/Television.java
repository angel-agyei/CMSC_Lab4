/** 
*The purpose of this class is to model a television
* Angel Agyei- 09/30/21
*/
public class Television {

	public static void main(String[] args) {
	}

		private final String MANUFACTURER ; //manufacturer- Tashiba
		private final int SCREEN_SIZE ; //size of the TV Screen- Randomized
		private boolean powerOn; //Either powered on or powered off
		private int channel; //what channel the tv is on - number is inputed
		private int volume; //volume of the tv and wether its increased  or decreased

		  
		public Television(String manu,int screen){
		MANUFACTURER = manu;
		SCREEN_SIZE = screen;
		powerOn = false;
		volume = 20;
		channel = 2;
		}
		//tell the manufacturer of the TV and in this case its LG
		public String getManufacturer(){
		return MANUFACTURER;
		}
		//This should return the screen size as an output(result)
		public int getScreenSize(){
		return SCREEN_SIZE;
		}
		// Indicates if the TV power is on/off
		public void power(){
		powerOn = !powerOn;
		}
		//tells the current volume of the TV as a result
		public int getTvVolume(){
		return volume;
		}
		//this should increase the current TV volume by 1
		public void increaseVolume(){
		volume+=1;
		}
		//this should decrease the current TV volume by 1
		public void decreaseVolume(){
		volume-=1;
		}
		//tells the current channel- as a number
		public int getChannel(){
		return channel;
		}
		//turns the channel to a given number- input a number
		public void setChannel(int ch){
		channel=ch;

	
		
	}// end of class

}// end of main
